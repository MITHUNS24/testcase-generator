const express = require('express');
const app = express();

app.get('/api/users', (req, res) => {
  res.json({ users: [] });
});

app.post('/api/auth/login', (req, res) => {
  res.json({ token: 'abc123' });
});

app.post('/api/auth/signup', (req, res) => {
  res.json({ user: {} });
});

app.get('/api/projects', (req, res) => {
  res.json({ projects: [] });
});

app.delete('/api/projects/:id', (req, res) => {
  res.json({ success: true });
});